G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-02-23T19:36:47-06:00*
G04 #@! TF.ProjectId,ButtonToActionChallenge,42757474-6f6e-4546-9f41-6374696f6e43,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-02-23 19:36:47*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.265000X-0.761000X0.636000X-0.761000X-0.636000X0.761000X-0.636000X0.761000X0.636000X0*%
%ADD11O,2.052000X1.802000*%
%ADD12C,2.802000*%
%ADD13RoundRect,0.265000X0.636000X0.786000X-0.636000X0.786000X-0.636000X-0.786000X0.636000X-0.786000X0*%
%ADD14O,1.802000X2.102000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X139717000Y-71120000D03*
D11*
X139717000Y-73620000D03*
X139717000Y-76120000D03*
X139717000Y-78620000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H1*
X164900000Y-73100000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J5*
X149500000Y-69300000D03*
D14*
X147000000Y-69300000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J6*
X149500000Y-77800000D03*
D14*
X147000000Y-77800000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X159000000Y-77800000D03*
D14*
X156500000Y-77800000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J2*
X159000000Y-69300000D03*
D14*
X156500000Y-69300000D03*
G04 #@! TD*
M02*
