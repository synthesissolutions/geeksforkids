G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-07-30T17:36:02-05:00*
G04 #@! TF.ProjectId,RyderSteeringButtonHolder,52796465-7253-4746-9565-72696e674275,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-07-30 17:36:02*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.150000X-0.150000X-0.625000X0.150000X-0.625000X0.150000X0.625000X-0.150000X0.625000X0*%
%ADD11RoundRect,0.250000X-0.350000X-0.650000X0.350000X-0.650000X0.350000X0.650000X-0.350000X0.650000X0*%
%ADD12RoundRect,0.300000X-0.441942X-1.431891X1.431891X0.441942X0.441942X1.431891X-1.431891X-0.441942X0*%
%ADD13RoundRect,0.300000X-1.431891X0.441942X0.441942X-1.431891X1.431891X-0.441942X-0.441942X1.431891X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X99000000Y-106500000D03*
X100000000Y-106500000D03*
X101000000Y-106500000D03*
D11*
X97700000Y-110375000D03*
X102300000Y-110375000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J2*
X96464466Y-96464466D03*
D13*
X96464466Y-103535534D03*
D12*
X103535534Y-103535534D03*
D13*
X103535534Y-96464466D03*
G04 #@! TD*
M02*
