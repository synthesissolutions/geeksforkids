G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2025-10-16T21:12:59-05:00*
G04 #@! TF.ProjectId,large_button,6c617267-655f-4627-9574-746f6e2e6b69,V2*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2025-10-16 21:12:59*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10RotRect,1.800000X1.800000X120.000000*%
%ADD11C,1.800000*%
%ADD12C,2.700000*%
%ADD13C,1.700000*%
%ADD14C,4.000000*%
%ADD15C,2.200000*%
%ADD16RotRect,1.800000X1.800000X240.000000*%
%ADD17R,2.500000X2.200000*%
%ADD18R,1.550000X2.200000*%
%ADD19R,1.800000X1.800000*%
%ADD20RoundRect,0.250000X-0.600000X-0.725000X0.600000X-0.725000X0.600000X0.725000X-0.600000X0.725000X0*%
%ADD21O,1.700000X1.950000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D4*
X-15819483Y-10599852D03*
D11*
X-17089483Y-8400148D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H1*
X0Y-17500000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW2*
X9584356Y-11399409D03*
D14*
X12124356Y-7000000D03*
D13*
X14664356Y-2600591D03*
D15*
X8994947Y-2260295D03*
X8019651Y-9029557D03*
G04 #@! TD*
D16*
G04 #@! TO.C,D3*
X17089482Y-8400148D03*
D11*
X15819482Y-10599852D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW1*
X5080000Y14000000D03*
D14*
X0Y14000000D03*
D13*
X-5080000Y14000000D03*
D15*
X-2540000Y8920000D03*
X3810000Y11460000D03*
G04 #@! TD*
D17*
G04 #@! TO.C,D1*
X1050000Y0D03*
D18*
X-1525000Y0D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H3*
X15155445Y8750000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW3*
X-14664356Y-2600591D03*
D14*
X-12124356Y-7000000D03*
D13*
X-9584356Y-11399409D03*
D15*
X-6454947Y-6659705D03*
X-11829651Y-2430443D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H2*
X-15155445Y8750000D03*
G04 #@! TD*
D19*
G04 #@! TO.C,D2*
X-1270000Y19000000D03*
D11*
X1270000Y19000000D03*
G04 #@! TD*
D20*
G04 #@! TO.C,J1*
X-3040000Y-13215000D03*
D21*
X-540000Y-13215000D03*
X1960000Y-13215000D03*
X4460000Y-13215000D03*
G04 #@! TD*
M02*
